# نظام تطوير الذات — مشروع Android

## محتويات المشروع
- واجهة عربية RTL بتصميم سينمائي أسود/أحمر.
- شخصية الواجهة والشعار البكسلي المخصص.
- تطبيق HTML الأصلي مع الحفاظ على الأقسام السبعة والمهارات والصور ونقاط SP وإدارة الأقسام.
- غلاف Android WebView لتشغيل المشروع كتطبيق أندرويد.
- حفظ البيانات محلياً باستخدام localStorage وIndexedDB داخل WebView.

## إنشاء APK
1. افتح مجلد `Nizam_Tatweer_Android` في Android Studio.
2. انتظر مزامنة Gradle وتثبيت Android SDK Platform 35 وBuild Tools.
3. اختر Build ثم Build Bundle(s) / APK(s) ثم Build APK(s).
4. ستجد الملف الناتج في `app/build/outputs/apk/debug/app-debug.apk`.

## ملاحظات
- هذا تسليم مشروع Android Studio قابل للبناء، وليس APK جاهزاً بعد.
- لم يتم توليد APK في بيئة العمل الحالية لعدم توفر Android SDK وGradle هنا.
- النسخة الحالية تحتفظ ببياناتها على الجهاز نفسه؛ لا توجد مزامنة سحابية.
